# Instrucțiuni de rulare

# Obiectiv : Să se modifice proiectul încât să treacă testele

# Pași pentru a rula testele și a trimite tema
1. Creați un repository privat pentru tema curentă
2. Clonați repository-ul nou
3. Copiați conținutul temei în repository-ul nou creat
4. Din directorul `main` rulați `npm install`
5. Din directorul `main` rulați `npm test`
6. Faceți commit și push pentru schimbările făcute
7. Dați share repository-ului cu `andrei_toma_` sau `andrei.toma@ie.ase.ro`